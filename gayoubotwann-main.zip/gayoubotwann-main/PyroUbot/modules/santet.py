import asyncio
from PyroUbot import *

__MODULE__ = "santet"
__HELP__ = """
📚 <b>--Folder Untuk VcTools--</b>

<blockquote><b>🚦 Perintah : <code>{0}santet</code>
🦠 Penjelasan : Animasi Untuk MengPrank Temen Anda.</b></blockquote>
"""

@WANN.UBOT("santet")
async def santet_online(client, message):
    await message.edit_text("Anda Telah Mengaktifkan Perintah Santet Online ツ")
    await asyncio.sleep(2)

    await message.edit_text("Mencari Nama Orang Ini...")
    await asyncio.sleep(1)

    await message.edit_text("Santet Online Segera Dilakukan")
    await asyncio.sleep(1)

    progress = ["▎", "▍", "▌", "▊", "▉", "█"]
    for i in range(101):
        bar = "█" * (i // 10) + progress[i % len(progress)]
        await message.edit_text(f"{i}%   {bar}")
        await asyncio.sleep(0.03)

    await message.edit_text("Target Berhasil Tersantet Online:v")
