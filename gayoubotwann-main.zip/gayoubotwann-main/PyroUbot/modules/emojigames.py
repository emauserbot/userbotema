from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "emojigames"
__HELP__ = """
📚 <b>--Folder Untuk Emoji Games--</b>

<blockquote><b>🚦 Perintah : <code>{0}dice [angka]</code></b>
🦠 <b>Penjelasan :</b> Melempar dadu, bisa menentukan angka yang diinginkan (1-6).</blockquote>
<blockquote><b>🚦 Perintah : <code>{0}dart [angka]</code></b>
🦠 <b>Penjelasan :</b> Melempar anak panah ke target, bisa menentukan angka (1-6).</blockquote>
<blockquote><b>🚦 Perintah : <code>{0}basket [angka]</code></b>
🦠 <b>Penjelasan :</b> Melempar bola basket ke ring, bisa menentukan angka (1-5).</blockquote>
<blockquote><b>🚦 Perintah : <code>{0}bowling [angka]</code></b>
🦠 <b>Penjelasan :</b> Melempar bola bowling, bisa menentukan angka (1-6).</blockquote>
<blockquote><b>🚦 Perintah : <code>{0}ball [angka]</code></b>
🦠 <b>Penjelasan :</b> Menendang bola ke gawang, bisa menentukan angka (1-5).</blockquote>
<blockquote><b>🚦 Perintah : <code>{0}jackpot [angka]</code></b>
🦠 <b>Penjelasan :</b> Memutar mesin jackpot, bisa menentukan angka (1-64).</blockquote>
"""


async def roll_dice(client, message, emoji):
    input_str = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None
    await message.delete()
    
    r = await client.send_dice(message.chat.id, emoji=emoji)
    
    if input_str:
        try:
            required_number = int(input_str)
            while r.dice.value != required_number:
                await r.delete()
                r = await client.send_dice(message.chat.id, emoji=emoji)
        except ValueError:
            pass


@WANN.UBOT("dice")
async def dice(client, message):
    await roll_dice(client, message, "🎲")


@WANN.UBOT("dart")
async def dart(client, message):
    await roll_dice(client, message, "🎯")


@WANN.UBOT("basket")
async def basket(client, message):
    await roll_dice(client, message, "🏀")


@WANN.UBOT("bowling")
async def bowling(client, message):
    await roll_dice(client, message, "🎳")


@WANN.UBOT("ball")
async def ball(client, message):
    await roll_dice(client, message, "⚽")


@WANN.UBOT("jackpot")
async def jackpot(client, message):
    await roll_dice(client, message, "🎰")
