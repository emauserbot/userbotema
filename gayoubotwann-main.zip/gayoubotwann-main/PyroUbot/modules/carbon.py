__MODULE__ = "carbon"
__HELP__ = """
📚 <b>--Folder Untuk Carbon--</b>

<blockquote><b>🚦 Perintah : <code>{0}carbon</code>
🦠 Penjelasan : Membuat Text Carbonara.</b></blockquote>
"""
