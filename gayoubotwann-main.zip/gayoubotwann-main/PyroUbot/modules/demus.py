import requests
import json
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from pytgcalls.exceptions import NoActiveGroupCall
from pyrogram import Client, filters
from pyrogram.types import Message
from asyncio import get_event_loop
from functools import partial
import yt_dlp
from yt_dlp import YoutubeDL
from yt_dlp.utils import DownloadError
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality, VideoQuality
from pytgcalls.types.calls import Call
from pyrogram.errors import ChatAdminRequired, UserBannedInChannel
from pytgcalls.exceptions import NotInCallError
from youtubesearchpython import VideosSearch
import os
import wget
import math
from datetime import timedelta
from time import time
from pyrogram.errors import FloodWait, MessageNotModified
from pyrogram.enums import ChatType
from PyroUbot import *

__MODULE__ = "vctools"
__HELP__ = """
📚 <b>--Folder Untuk VcTools--</b>

<blockquote><b>🚦 Perintah : <code>{0}jvc</code>
🦠 Penjelasan : Untuk Bergabung Ke Voice Chat Group.</b></blockquote>
<blockquote><b>🚦 Perintah : <code>{0}lvc</code>
🦠 Penjelasan : Untuk Meninggalkan Dari Voice Chat Group.</b></blockquote>
"""

__MODULE__ = "playos"
__HELP__ = """
📚 <b>--Folder Untuk Play Os--</b>

<blockquote><b>🚦 Perintah : <code>{0}play</code>
🦠 Penjelasan : Untuk Memulai Play Ke Call Group Os.</b></blockquote>
<blockquote><b>🚦 Perintah : <code>{0}end</code>
🦠 Penjelasan : Untuk Meninggalkan Dari Voice Chat/Play.</b></blockquote>
<blockquote><b>🚦 Perintah : <code>{0}splay</code>
🦠 Penjelasan : Untuk Memulai Play Menggunakan Reply Sound Yang Ingin Di Putar Di Os.</b></blockquote>
<blockquote><b>🚦 Perintah : <code>{0}vplay</code>
🦠 Penjelasan : Untuk Memulai Play Menggunakan Reply Video Yang Ingin Di Putar Di Os</b></blockquote>
"""

@WANN.UBOT("play")
@WANN.TOP_CMD
async def play_cmd(client, message):
    if len(message.command) < 3:
        return await message.reply_text(
            "❌ <b>Format salah!</b>\nGunakan:\n"
            "<code>.play -s judul</code> untuk audio\n"
            "<code>.play -v judul</code> untuk video"
        )

    mode = message.command[1].lower()
    if mode not in ["-s", "-v"]:
        return await message.reply_text(
            "❌ <b>Mode tidak valid!</b>\nGunakan:\n"
            "<code>.play -s judul</code> untuk audio\n"
            "<code>.play -v judul</code> untuk video"
        )

    infomsg = await message.reply_text("<b>🔍 Mencari...</b>", quote=False)
    query = " ".join(message.command[2:])

    try:
        search = VideosSearch(query, limit=1).result()["result"][0]
        link = f"https://youtu.be/{search['id']}"
    except Exception as error:
        return await infomsg.edit(f"<b>🔍 Pencarian gagal:\n\n{error}</b>")

    chat_id = message.chat.id
    active_calls = await client.call_py.calls
    if chat_id in active_calls:
        return await infomsg.edit_text("<b>🚫 Sedang ada musik yang diputar di grup ini!</b>")

    try:
        if mode == "-s":
            file_name, title, url, duration, views, channel, thumb, data_ytp = await YoutubeDownload(link, as_video=False)
        else:
            file_name, title, url, duration, views, channel, thumb, data_ytp = await YoutubeDownload(link, as_video=True)
    except Exception as error:
        return await infomsg.edit(f"<b>📥 Gagal mengunduh:\n\n{error}</b>")

    thumbnail_path = f"{search['id']}.jpg"
    wget.download(thumb, thumbnail_path)

    try:
        if mode == "-a":
            await client.call_py.play(
                chat_id,
                MediaStream(
                    file_name,
                    AudioQuality.STUDIO,
                    ytdlp_parameters="--cookies cookies.txt",
                ),
            )
        else:
            await client.call_py.play(
                chat_id,
                MediaStream(
                    file_name,
                    AudioQuality.HIGH,
                    VideoQuality.HD_720p,
                    ytdlp_parameters="--cookies cookies.txt",
                ),
            )
    except Exception as error:
        return await infomsg.edit(f"<b>🚫 Gagal Memutar:</b>\n{error}")

    await client.send_photo(
        message.chat.id,
        photo=thumbnail_path,
        caption=data_ytp.format(
            "sᴜᴄᴄᴇs ᴘʟᴀʏɪɴɢ",
            title,
            timedelta(seconds=duration),
            views,
            channel,
            url,
            bot.me.mention,
        ),
        reply_to_message_id=message.id,
    )
    
    await infomsg.delete()
    
    for files in (thumbnail_path, file_name):
        if files and os.path.exists(files):
            os.remove(files)
            
@WANN.UBOT("jvc|startvc")
@WANN.TOP_CMD
async def join_vc(client, message):
    try:
        mex = await message.reply(f"proccesing...")
        await client.call_py.play(message.chat.id)
        await client.call_py.mute_stream(message.chat.id)
        await mex.edit(f"**berhasil join ke voice chat**")        
    except ChatAdminRequired:
        await mex.edit(f"**maaf tidak bisa join vc**")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)

@WANN.UBOT("lvc|end")
@WANN.TOP_CMD
async def leave_vc(client, message):
    try:
        mex = await message.reply(f"proccesing...")
        await client.call_py.leave_call(message.chat.id)
        await mex.edit(f"berhasil turun dari obrolan suara")
    except NotInCallError:
        await mex.edit(f"belum bergabung ke voice chat")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)
        
@WANN.UBOT("splay")
async def _(client, message):
    msg = await message.reply_text(f"<b>Processing play...</b>")
    if message.reply_to_message:
        media = message.reply_to_message.audio or message.reply_to_message.voice
        if media:
            await msg.edit(f"<b>Downloading {'audio' if message.reply_to_message.audio else 'voice'}...</b>")
            file_name = await client.download_media(media)
            title = "Audio" if message.reply_to_message.audio else "Voice"
            duration = media.duration or 0
            channel = "Local Audio" if message.reply_to_message.audio else "Local Voice"
            views = "N/A"
        else:
            return await msg.edit("<b>This media is not supported!</b>")
    else:
        return await msg.edit("<b>Reply to media voice or audio!</b>")

    chat_id = message.chat.id
    a_calls = await client.call_py.calls
    if_chat = a_calls.get(chat_id)
    if if_chat:
        return await msg.edit("<b>Already play music in voice chat!</b>")

    try:
        await client.call_py.play(chat_id, MediaStream(
            file_name,
            video_flags=MediaStream.Flags.IGNORE,
            audio_parameters=AudioQuality.STUDIO,
        ))
        await msg.edit(f"""
<b>
Playing song!
 Title: {title}
 Duration: {duration}
 Views: {views}
 Channel: {channel}
</b>
""")
    except NoActiveGroupCall:
        await msg.edit("<b>No active voice calls!</b>")
    except Exception as e:
        await msg.edit(f"<b>Error!\n <code>{e}</code></b>")
    finally:
        if os.path.exists(file_name):
            os.remove(file_name)
        
@WANN.UBOT("vplay")
async def _(client, message):
    reply = message.reply_to_message
    msg = await message.reply_text(f"<b>Processing vplay...</b>")

    if reply:
        media = reply.video
        if media:
            await msg.edit_text(f"<b>Downloading video...</b>")
            playing = await client.download_media(media)
            title = "Video"
            duration = media.duration or 0
            channel = "Local Video"
            views = "N/A"
        else:
            return await msg.edit_text("<b>This media is not supported!</b>")
    else:
        return await msg.edit_text("<b>Reply to media video!</b>")

    chat_id = message.chat.id
    a_calls = await client.call_py.calls
    if_chat = a_calls.get(chat_id)
    if if_chat:
        return await msg.edit_text("<b>Already play video in call chat!</b>")

    try:
        await client.call_py.play(
            chat_id,
            MediaStream(
                playing,
                audio_parameters=AudioQuality.HIGH,
                video_parameters=VideoQuality.HD_720p,
            )
        )
        await msg.edit_text(f"""
<b>
Playing video!
 Title: {title}
 Duration: {duration}
 Views: {views}
 Channel: {channel}
</b>
""")
    except NoActiveGroupCall:
        return await msg.edit_text("<b>No active voice calls!</b>")
    except Exception as e:
        return await msg.edit_text(f"<b>Error!\n <code>{str(e)}</code></b>")
    finally:
        if os.path.exists(playing):
            os.remove(playing)